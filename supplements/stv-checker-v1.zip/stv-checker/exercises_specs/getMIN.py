from formalspecs.checker import Checker

#
# Formalize the pre- and post-conditions of the program below.
# 
# For your submitted solution we want formalization in Mathematical
# formulas! 
# 
# You can test your idea by first formalizing them in Python, and then use the 
# stv-checker to check them. The checker will say PASS if your candidate pre-
# and post-condition passeds all its tests. As the checker uses testing, 
# keep in mind that this is not a waterproof guarantee. Feel free to add 
# more tests.
#
# Invoke the checker from a unit test :) This is explained in the tool README.md.
#

# The program, whose pre-/post-conditions you are asked to formalize:
def getMIN(a:list[int]) -> int :
    """
    The program takes a non-null and non-empty integer "array" a, and returns the smallest 
    element of the array a. 
    
    Note:
    Since we don't have array natively in Python, we'll represent that with a list.
    We certainly can use numpy array, but that seems overkill for this exercise; so
    list it is then.
    """
    m = a[0]
    tail = a[1:]
    if tail==[]: return m
    for x in tail:
        if x<m: m = x
    return m

# You can Python-formulate the pre-condition here. 
#   * Use only logical, arithmetic operators, and array length operator.
#   * Don't use assignment! 
#   * In Python there is no "null". But you do have None. 
#     Use "x is not None" if you want to say that x should not be None.
#
def precondition(a:list[int]) -> bool :
    return None # dummy pre-cond

# You can Python-formulate the post-condition here.
#    * Use only logical, arithmetic operators, array length operator
#      and quantifiers: forall or existential. 
#    * Don't use assignment!
#    * As usual, 'retval' represents the return value of your program.
#
#   Math notation quantifiers and the corresponding Python encoding:
#
#     Math: (forall i: 0<=i<#a: P(a[i]))   --> Python: all([P(a[i]) for i in range(0,len(a))])
#     Math: (exists i: 0<=i<#a: P(a[i]))   --> Python: any([P(a[i]) for i in range(0,len(a))])
# 
#
def postcondition(retval:int, a:list[int]) -> bool :
    return all([a[i]]==0 for i in range(0,len(a)))  # dummy post-cond

# create an instance of stv-checker:
checker = Checker(getMIN,precondition,postcondition)

# tests to check the pre-cond:
checker.precondTests = [ (True,([-1],)), (True,([0,0],)), (False,([],)), (False,(None,)) ]
# negative tests to check the post-cond:
checker.postcondNegTests = [(0,[1]), (3,[3,2,1]), (3,[2,1,3]), (0,[1,2]), (3,[2,2])]
# positive tests to check the post-cond:
checker.postcondPosTests = [([0],),([-10,10],),([3,2,1],),([-1,10,-9],)]

#print(f">>> {checker.postcondPosTests}")
#print (f">>> {[ getMIN(*z) for z in checker.postcondPosTests] }")
#print (f">>> {[ getMIN(*z[1:]) for z in checker.postcondNegTests] }")