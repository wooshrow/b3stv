from formalspecs.checker import Checker
from formalspecs.utils import implies

#
# Formalize the pre- and post-conditions of the program below.
# 
# For your submitted solution we want formalization in Mathematical
# formulas! 
# 
# You can test your idea by first formalizing them in Python, and then use the 
# stv-checker to check them. The checker will say PASS if your candidate pre-
# and post-condition passeds all its tests. As the checker uses testing, 
# keep in mind that this is not a waterproof guarantee. Feel free to add 
# more tests.
#
# Invoke the checker from a unit test :) This is explained in the tool README.md.
#

# The program, whose pre-/post-conditions you are asked to formalize:
def getMIN_S(a:list[int]) -> int :
    """
    The program takesan array a whose elements are sorted increasingly. 
    Moreover all elements in are distinct. The program returns the least 
    element of the array, if it is non-empty.
    
    Note:
    Since we don't have array natively in Python, we'll represent that with a list.
    """
    if len(a)>0: return a[0]
    return None

# You can Python-formulate the pre-condition here. 
#   * Use only logical, arithmetic operators, and array length operator.
#     and quantifiers: forall or existential. 
#   * Don't use assignment! 
#   * In Python there is no "null". But you do have None. 
#     Use "x is not None" if you want to say that x should not be None.
#   * Python has no native "implication" operator, but you can use the one
#     imported from utils as in "implies(p,q)".
#   Math notation quantifiers and the corresponding Python encoding:
#
#     Math: (forall i: 0<=i<#a: P(a[i]))   --> Python: all([P(a[i]) for i in range(0,len(a))])
#     Math: (exists i: 0<=i<#a: P(a[i]))   --> Python: any([P(a[i]) for i in range(0,len(a))])
#
def precondition(a:list[int]) -> bool :
    return None # dummy pre-cond

# You can Python-formulate the post-condition here.
#    * Use only logical, arithmetic operators, array length operator
#      and quantifiers: forall or existential. 
#    * Don't use assignment!
#    * As usual, 'retval' represents the return value of your program.
#
def postcondition(retval:int, a:list[int]) -> bool :
    return all([a[i]]==0 for i in range(0,len(a)))  # dummy post-cond

# create an instance of stv-checker:
checker = Checker(getMIN_S,precondition,postcondition)

# tests to check the pre-cond:
checker.precondTests = [ (True,([-1],)), (True,([0,1],)), (True,([],)), (True,([2,3,4],)),
                         (False,(None,)), (False,([4,3],)), (False,([3,4,3],)), (False,([2,3,3],)) ]
# negative tests to check the post-cond:
checker.postcondNegTests = [(0,[1]), (3,[1,2,3]), (2,[1,2,3])]
# positive tests to check the post-cond:
checker.postcondPosTests = [([0],),([-10,10],),([-3,-2,1],),([1000,1001,12345],)]

print(f">>> {checker.postcondPosTests}")
print (f">>> {[ getMIN_S(*z) for z in checker.postcondPosTests] }")
print (f">>> {[ getMIN_S(*z[1:]) for z in checker.postcondNegTests] }")
