from formalspecs.checker import Checker

#
# Formalize the pre- and post-conditions of the program below.
# 
# For your submitted solution we want formalization in Mathematical
# formulas! 
# 
# You can test your idea by first formalizing them in Python, and then use the 
# stv-checker to check them. The checker will say PASS if your candidate pre-
# and post-condition passeds all its tests. As the checker uses testing, 
# keep in mind that this is not a waterproof guarantee. Feel free to add 
# more tests.
#
# Invoke the checker from a unit test :) This is explained in the tool README.md.
#

silent = True

# The program, whose pre-/post-conditions you are asked to formalize:
def isTriangle(x:int, y:int, z:int)-> bool :
    """
    The program takes three positive integers representing the sides of a triangle. 
    It returns true if these sides really form a triangle. This is the case 
    if none of the side is equal to or larger than the sum of the other two. 
    Else, the program returns false
    """
    try:
        d =  x - y
        if d - z >= 0 : raise Exception("x is too long")
        d = y - x
        if d - z >= 0 : raise Exception("y is too long")
        d = z - x
        if d - y >= 0 : raise Exception("z is too long")
        return True
    except Exception as e:
        if not silent: print(">>> " + str(e))
        return False

# You can Python-formulate the pre-condition here. 
#  * Use only logical and arithmetic operators. 
#  * Don't use assignment.
def precondition(x:int, y:int, z:int) -> bool :
    return None # dummy pre-cond

# You can Python-formulate the post-condition here.
#   * Use only logical and arithmetic operators. 
#   * Don't use assignment.
#   * 'retval' represents the return value of your program.
#
def postcondition(retval:bool, x:int, y:int, z:int) -> bool :
    return None # dummy post-cond

# create an instance of stv-checker:
checker = Checker(isTriangle,precondition,postcondition)

# tests to check the pre-cond:
checker.precondTests = [ (True,(1,1,1)), (True,(2,2,1)), (True,(4,3,2)), (True,(4,3,1)),
                         (False,(2,2,0)),
                         (False,(-1,2,3)), 
                         (False,(4,0,2)) ]
# negative tests to check the post-cond:
checker.postcondNegTests = [(True,1,2,1),(True,2,1,1),(True,1,1,2),
                            (True,1,2,3),(True,10,2,5),
                            (False,1,1,1),(False,1000,1,1000),(False,5,4,2)
                            ]
# positive tests to check the post-cond:
checker.postcondPosTests = [(1,1,1),
                            (2,2,1),(1,5,5),(1000,1,1000),
                            (2,4,5),(4,2,5),(2,5,4),(4,5,2),(5,2,4),(5,4,2)]


#print (f">>> {[ isTriangle(*z) for z in checker.postcondPosTests] }")
#print (f">>> {[ isTriangle(*z[1:]) for z in checker.postcondNegTests] }")