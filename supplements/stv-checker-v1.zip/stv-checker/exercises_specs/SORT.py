from formalspecs.checker import Checker

#
# Formalize the pre- and post-conditions of the program below.
#
# For your submitted solution we want formalization in Mathematical
# formulas!
#
# You can test your idea by first formalizing them in Python, and then use the
# stv-checker to check them. The checker will say PASS if your candidate pre-
# and post-condition passeds all its tests. As the checker uses testing,
# keep in mind that this is not a waterproof guarantee. Feel free to add
# more tests.
#
# Invoke the checker from a unit test :) This is explained in the tool README.md.
#

# The program, whose pre-/post-conditions you are asked to formalize:
def SORT(a:list[int]) -> list[int] :
    """
    The program takes a non-null integer array a containing distinct elements.
    It returns a copy of a, but sorted in the increasing order.

    Note:
    Since we don't have array natively in Python, we'll represent that with a list.
    We certainly can use numpy array, but that seems overkill for this exercise; so
    list it is then.
    """
    b = a.copy()
    N = len(b)
    if N <= 1 : return b

    def findMinInd(k):
        mval = b[k]
        m = k
        for i in range(k,N) :
            y = b[i]
            if y < mval :
                mval = y
                m = i
        return m

    for k in range(0,N-1):
        m = findMinInd(k)
        # swap:
        tmp = b[k]
        b[k] = b[m]
        b[m] = tmp

    return b


def implies(p:bool, q:bool) -> bool : return not p or q

# You can Python-formulate the pre-condition here.
#   * Use only logical, arithmetic operators.
#   * Use quantifiers: forall or existential.
#   * Don't use assignment!
#   * Don't use list to set conversion.
#   * In Python there is no "null". But you do have None.
#     Use "x is not None" if you want to say that x should not be None.
#   * Python has no native "implication" operator, but you can use the one
#     defined above as in "implies(p,q)".
#
def precondition(a:list[int]) -> bool :
    return None # dummy pre-cond

# You can Python-formulate the post-condition here.
#    * Use only logical, arithmetic operators, array length operator
#    * Use quantifiers: forall or existential.
#    * Don't use assignment!
#    * As usual, 'retval' represents the return value of your program.
#
#   Math notation quantifiers and the corresponding Python encoding:
#
#     Math: (forall i: 0<=i<#a: P(a[i]))   --> Python: all([P(a[i]) for i in range(0,len(a))])
#     Math: (exists i: 0<=i<#a: P(a[i]))   --> Python: any([P(a[i]) for i in range(0,len(a))])
#
#     Quantifier with multiple bound-vars, e.g.:
#     Math: (exists i,k : 0<=i<3 /\ 0<=k<3 : P(i,k))  --> Python: any([P(i,k) for i in range(0,3)] for k in range(0,3)])
#
#
def postcondition(retval:list[int], a:list[int]) -> bool :
    return any([a[i]]==0 for i in range(0,len(a)))  # dummy post-cond

# create an instance of stv-checker:
checker = Checker(SORT,precondition,postcondition)

# tests to check the pre-cond:
checker.precondTests = [ (True,([],)), (True,([1],)), (True,([3,1],)),
                         (False,(None,)), (False,([2,1,3,1],)) ]
# negative tests to check the post-cond:
checker.postcondNegTests = [([],[1]), ([1,1],[1]), ([2,1],[1,2]), ([1],[1,2]),
                            ([1,2],[3,4]), ([1,1],[1]), ([1,2],[1]) ]
# positive tests to check the post-cond:
checker.postcondPosTests = [([],),([1],),([1,2,3],),([3,2,1],),([1,3,2],) ]

#a = [3,2,2,1]
#print(f">>> {SORT(a)}, orig a={a}")
#print(f">>> {checker.postcondPosTests}")
#print (f">>> {[ SORT(*z) for z in checker.postcondPosTests] }")
print (f">>> {[ SORT(*z[1:]) for z in checker.postcondNegTests] }")
