from formalspecs.checker import Checker

#
# Formalize the pre- and post-conditions of the program below.
# 
# For your submitted solution we want formalization in Mathematical
# formulas! 
# 
# You can test your idea by first formalizing them in Python, and then use the 
# stv-checker to check them. The checker will say PASS if your candidate pre-
# and post-condition passeds all its tests. As the checker uses testing, 
# keep in mind that this is not a waterproof guarantee. Feel free to add 
# more tests.
#
# Invoke the checker from a unit test :) This is explained in the tool README.md.
#

# The program, whose pre-/post-conditions you are asked to formalize:
def myMIN(x:int, y:int)-> int :
    """
    This program returns the minimum of the two integers. 
    """
    dif = y - x 
    return y if dif <=0 else x

# You can Python-formulate the pre-condition here. 
def precondition(x:int, y:int) -> bool :
    return x != y # dummy pre-cond

# You can Python-formulate the post-condition here.
#   * Use only logical and arithmetic operators. 
#   * Don't use Python built in "min"-function.
#   * Don't use assignment.
#   * 'retval' represents the return value of your program.
#
def postcondition(retval:int, x:int, y:int) -> bool :
    return retval <= y # dummy post-cond

# create an instance of stv-checker:
checker = Checker(myMIN,precondition,postcondition)

# tests to check the pre-cond:
checker.precondTests = [ (True,(1,2)), (True,(-1,-2)), (True,(0,0)) ]
# negative tests to check the post-cond:
checker.postcondNegTests = [(-9,1,2),(-9,0,0),(2,-1,2),(2,2,0),(0,1,1)]
# positive tests to check the post-cond:
checker.postcondPosTests = [(-1,-2),(-1,1),(0,0),(1,1),(1,9),(9,2)]

