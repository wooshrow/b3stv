from formalspecs.checker import Checker

#
# Formalize the pre- and post-conditions of the program below.
# 
# For your submitted solution we want formalization in Mathematical
# formulas! 
# 
# You can test your idea by first formalizing them in Python, and then use the 
# stv-checker to check them. The checker will say PASS if your candidate pre-
# and post-condition passeds all its tests. As the checker uses testing, 
# keep in mind that this is not a waterproof guarantee. Feel free to add 
# more tests.
#
# Invoke the checker from a unit test :) This is explained in the tool README.md.
#

# The program, whose pre-/post-conditions you are asked to formalize:
def INTERSECT(a:list[int], b:list[int]) -> list[int] :
    """
    The program returns an array containing integers that appear in both a and b. 
    The returned array should not contain any duplicate. Both a and b are assumed 
    to be not null.
    
    Note:
    Since we don't have array natively in Python, we'll represent that with a list.
    """
    # can just do list(set([ x for x in a for y in b if x==y])) :D
    # but let's imagine someone gives the following implementation:
    N = len(a)
    M = len(b)
    r = set() # empty set in Python
    for i in range(0,N):
        x = a[i]
        for k in range(0,M):
            if x == b[k] : r.add(x)
    return list(r)


# You can Python-formulate the pre-condition here. 
#   * Use only logical, arithmetic operators.
#   * Don't use assignment! 
#   * In Python there is no "null". But you do have None. 
#     Use "x is not None" if you want to say that x should not be None.
#
def precondition(a:list[int], b:list[int]) -> bool :
    return None # dummy pre-cond

# You can Python-formulate the post-condition here.
#    * Use only logical, arithmetic operators, array length operator
#    * Use quantifiers: forall or existential. 
#    * Dont use "x in a" or "x in b" to check membership of a or b
#    * Don't use assignment!
#    * As usual, 'retval' represents the return value of your program.
#
#   Math notation quantifiers and the corresponding Python encoding:
#
#     Math: (forall i: 0<=i<#a: P(a[i]))   --> Python: all([P(a[i]) for i in range(0,len(a))])
#     Math: (exists i: 0<=i<#a: P(a[i]))   --> Python: any([P(a[i]) for i in range(0,len(a))])
#
#     Quantifier with multiple bound-vars, e.g.:
#     Math: (exists i,k : 0<=i<3 /\ 0<=k<3 : P(i,k))  --> Python: any([P(i,k) for i in range(0,3)] for k in range(0,3)])
# 
#
def postcondition(retval:list[int], a:list[int], b:list[int]) -> bool :
    return any([a[i]]==0 for i in range(0,len(a)))  # dummy post-cond

# create an instance of stv-checker:
checker = Checker(INTERSECT,precondition,postcondition)

# tests to check the pre-cond:
checker.precondTests = [ (True,([-1],[])), (True,([],[0,0])), (True,([],[])), (False,(None,[1])), (False,([1],None)) ]
# negative tests to check the post-cond:
checker.postcondNegTests = [([1],[1],[]), ([1,1],[1,1],[1,1]), ([1,1],[2,1,1],[3,1]), 
                            ([],[1],[1]), ([1,2,3],[1,2,3],[2,1]) ]
# positive tests to check the post-cond:
checker.postcondPosTests = [([0],[]),([],[3,3]),([1,2,2,3],[3,2,2]),([1,2,3],[3,2,1]),
                            ([1,2,3],[4,5,2]), ([0,0,0], [0,0])
                            ]

print(f">>> {checker.postcondPosTests}")
print (f">>> {[ INTERSECT(*z) for z in checker.postcondPosTests] }")
print (f">>> {[ INTERSECT(*z[1:]) for z in checker.postcondNegTests] }")

