from formalspecs.checker import Checker

#
# Formalize the pre- and post-conditions of the program below.
# 
# For your submitted solution we want formalization in Mathematical
# formulas! 
# 
# You can test your idea by first formalizing them in Python, and then use the 
# stv-checker to check them. The checker will say PASS if your candidate pre-
# and post-condition passeds all its tests. As the checker uses testing, 
# keep in mind that this is not a waterproof guarantee. Feel free to add 
# more tests.
#
# Invoke the checker from a unit test :) This is explained in the tool README.md.
#

# The program, whose pre-/post-conditions you are asked to formalize:
def isMIN(m:int, x:int, y:int)-> bool :
    """
    This program checks if m is the minimum of x and y. If so, 
    it returns true, and else false.
    """
    if m==x:
        return m <= y
    elif m==y:
        return m <= x
    else:
        return False

# You can Python-formulate the pre-condition here. 
def precondition(m:int, x:int, y:int) -> bool :
    return None # dummy pre-cond

# You can Python-formulate the post-condition here.
#   * Use only logical and arithmetic operators. 
#   * Don't use Python built in "min"-function.
#   * Don't use assignment.
#   * 'retval' represents the return value of your program.
#
def postcondition(retval:bool, m:int, x:int, y:int) -> bool :
    return None # dummy post-cond

# create an instance of stv-checker:
checker = Checker(isMIN,precondition,postcondition)

# tests to check the pre-cond:
checker.precondTests = [ (True,(1,1,2)), (True,(-1,-1,-2)), (True,(1,0,0)), (True,(-2,-1,-1)), (True,(4,2,2)) ]
# negative tests to check the post-cond:
checker.postcondNegTests = [(True,-9,1,2),(True,-9,0,0),(False,-1,-1,2),(False,0,2,0),(True,0,1,1)]
# positive tests to check the post-cond:
checker.postcondPosTests = [(-2,-1,-2),(-1,-1,-2),(-2,-1,1),(0,0,0),(1,0,0),(-1,0,0),(1,1,9),(9,9,2)]
