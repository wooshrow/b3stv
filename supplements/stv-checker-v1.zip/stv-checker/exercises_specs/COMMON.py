from formalspecs.checker import Checker

#
# Formalize the pre- and post-conditions of the program below.
#
# For your submitted solution we want formalization in Mathematical
# formulas!
#
# You can test your idea by first formalizing them in Python, and then use the
# stv-checker to check them. The checker will say PASS if your candidate pre-
# and post-condition passeds all its tests. As the checker uses testing,
# keep in mind that this is not a waterproof guarantee. Feel free to add
# more tests.
#
# Invoke the checker from a unit test :) This is explained in the tool README.md.
#

# The program, whose pre-/post-conditions you are asked to formalize:
def COMMON(a:list[int], b:list[int]) -> bool :
    """
    The program takes takes two non-null arrays of integers. It returns true if
    the two arrays have an element in common, else false.

    Note:
    Since we don't have array natively in Python, we'll represent that with a list.
    We certainly can use numpy array, but that seems overkill for this exercise; so
    list it is then.
    """
    N = len(a)
    M = len(b)
    if N==0 or M==0 : return False
    for i in range(0,N):
        x = a[i]
        for k in range(0,M):
            if x == b[k] : return True
    return False


# You can Python-formulate the pre-condition here.
#   * Use only logical, arithmetic operators.
#   * Don't use assignment!
#   * In Python there is no "null". But you do have None.
#     Use "x is not None" if you want to say that x should not be None.
#
def precondition(a:list[int], b:list[int]) -> bool :
    return None # dummy pre-cond

# You can Python-formulate the post-condition here.
#    * Use only logical, arithmetic operators, array length operator
#    * Use quantifiers: forall or existential.
#    * Don't use assignment!
#    * As usual, 'retval' represents the return value of your program.
#
#   Math notation quantifiers and the corresponding Python encoding:
#
#     Math: (forall i: 0<=i<#a: P(a[i]))   --> Python: all([P(a[i]) for i in range(0,len(a))])
#     Math: (exists i: 0<=i<#a: P(a[i]))   --> Python: any([P(a[i]) for i in range(0,len(a))])
#
#     Quantifier with multiple bound-vars, e.g.:
#     Math: (exists i,k : 0<=i<3 /\ 0<=k<3 : P(i,k))  --> Python: any([P(i,k) for i in range(0,3)] for k in range(0,3)])
#
#
def postcondition(retval:bool, a:list[int], b:list[int]) -> bool :
    return any([a[i]]==0 for i in range(0,len(a)))  # dummy post-cond

# create an instance of stv-checker:
checker = Checker(COMMON,precondition,postcondition)

# tests to check the pre-cond:
checker.precondTests = [ (True,([-1],[])), (True,([],[0,0])), (True,([],[])), (False,(None,[1])), (False,([1],None)) ]
# negative tests to check the post-cond:
checker.postcondNegTests = [(True,[1],[]), (True,[],[]), (True,[2,1,3],[4]),
                            (False,[1,2],[0,0,0,2]), (False,[0,2],[0,0,0,2]), (False,[1],[1,2])]
# positive tests to check the post-cond:
checker.postcondPosTests = [([0],[]),([1,2],[3]),([3],[1,2]),([],[]),
                            ([0],[0]), ([0,1],[1,0]), ([3],[0,1,2,3]), ([0,1,2,3],[3]), ([0,0,0], [0,0])
                            ]

#print(f">>> {checker.postcondPosTests}")
#print (f">>> {[ COMMON(*z) for z in checker.postcondPosTests] }")
#print (f">>> {[ COMMON(*z[1:]) for z in checker.postcondNegTests] }")
