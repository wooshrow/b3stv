## Example: loop-invariant and termination checking

Exercises on writing loop-invariants and temination metrics ate in `./exercises_invs`. Exercises on writing loop invariants are in ./exercises_invs. For example `P1.py` which looks like this:

```python
def P1(i:int, j:int) -> tuple[int,int] :
    # pre is i==2 and j==20
    while i<j :
        j = j-2
        i += 1
    # post is j==i
    return (i,j)

# define here your invariant
def inv(i:int, j:int) -> bool:
     return  ...

# define here your termination metric
def m(i:int, j:int) -> int :
     return ...
```

The program does not anything interesting, but still, it is a program with a loop. It is useful to check your understanding of loop-invariant.

The program's pre- and post-conditions are annotated as comments.

Your task is to come up with a **loop-invariant** and a **termination metric** that would prove that the program, if it starts in a state satisfying the pre-condition, will terminate with the said post-condition. Formulate your invariant in the function `inv()` above, and your temination metric in `m()` (that is, you have to modify them).


Let's as an example propose the following:


```python
def inv(i:int, j:int) -> bool:
     return i <= j  

def m(i:int, j:int) -> int :
     return j
```

The _m_ looks good, but the _inv_ is not actually not perfect. But for now, let's just take it as it is.

#### The Checker and the tests

Using STV-Checker you can **test** your invariant and termination metric using tests provided in the problem file `P1.py`. Note that the Checker does not construct a formal proof, so even if you pass all the tests, it if not a waterproof guarantee.

Further in the file `P1.py` you can see that it creates an instance of STV-Checker:

`checker = Checker(P1,precondition,postcondition)`

It then attaches various components to the checker e.g. a copy of the loop-body, and a copy of the loop-guard. Further down, you can see which tests are provided. There are two sets:

   * `precondTests` are tests used to check is the program establishes the invariant before the loop starts. So, they are used to check the INIT-condition: _{pre} S0 {I}_ where _S0_ is the statement before the loop (if we have any, else S0 is just skip).

   * `PinvTests` are tests used to check other loop conditions (INV, EXIT, TC1 and TC2).

### Running the invariant checker

As before, the recommended way to run the checker is from a test-file. For our example problem `P1.py`, create a file called e.g. `test_P1.py`. Put this file in the directory `./tests`. Alternatively, edit the file `incomplete_test_P1.py` in `./tests`.

Put this content in that file:

 ```python
from exercises_invs import P1 # import your P1

def test_simulator() :
    P1.checker.simulateLoop(2,20)

def test_INIT() :
  R = P1.checker.checkPinit()
  assert R.verdict == "PASS"

def test_INV() :
   R = P1.checker.checkPinv()
   assert R.verdict == "PASS"

def test_EXIT() :
  R = P1.checker.checkPexit()
  assert R.verdict == "PASS"

def test_TC1() :
  R = P1.checker.checkPTC1()
  assert R.verdict == "PASS"

def test_TC2() :
  R = P1.checker.checkPTC2()
  assert R.verdict == "PASS"
```

You can run the tests one at a time from Command Line:

   `pytest -v -s your-test-file::test-method`

The first test, `test_simulator` runs a simulator. It will run the program `P1` passing to it the arguments you specify there. So, in this example i=2 and j=20 as the arguments.
The simulator will print the program intemediate states, whether or not your invariant holds, and the value of _m_.  You will get something like this:

```
|>> Simulating P1(2, 20)
|   * state: <i:2, j:20>, m:18, inv:holds
|   > coming to the loop
|     > iter-1; state: <i:3, j:18>, m:15, inv:holds
|     > iter-2; state: <i:4, j:16>, m:12, inv:holds
|     > iter-3; state: <i:5, j:14>, m:9, inv:holds
|     > iter-4; state: <i:6, j:12>, m:6, inv:holds
|     > iter-5; state: <i:7, j:10>, m:3, inv:holds
|     > iter-6; state: <i:8, j:8>, m:0, inv:holds
|   * the loop exits
|   > state: <i:8, j:8>, m:0, post:holds
```


This is useful for debugging. **BUT note that even if the simulator shows that the invariant holds it does not mean that it is good enough** for e.g. the Exit-condition.

**The other five tests** will explicitly check each of the conditions for total correctness of a loop:

* `test_INIT()` tests the program can establish the invariant before the loop starts. So, it tests the condition _{pre} S0 {I}_ where _S0_ is the statement before the loop, if we have any.

* `test_INV()` tests that every iteration restores the invariant; so, the condition _{I and loop-guard} loop-body {I}_.

* `test_EXIT()` tests that after the loop terminates, the post-condition is estableshed. So, it checks the condition _{I and not loop-guard} S1 {post}_, where S1 is the statement after the loop.

* `test_TC1` checks that every iteration decreases your termination metric. So. the condition _{I and loop-guard} C:=m; loop-body {m<C}_

* `test_TC2` checks that _m_ has a lower bound; so, the condition _I and g implies m>0_.

Your inv and m should pass all these tests.


 To actually run the check we now need to run `test_P1.py` :

   `pytest -v -s your-test-file::test-method` to run a specific test method

Or else:

  `pytest -v -s your-test-file` to run all test methods in the file.

For example with the previous choice of invariant, _i <= j_, `test_EXIT` will pass, but not `test_INV`, which gives this as a counter example:

```
|>> Checking if the inv of P1 is restored after every iteration...
|   * testing with 276 tcs ...
+--
|   ** inv VIOLATED! state before: <i:20, j:21>
|                    state after : <i:21, j:19>
....
```

We see in this counter example that if we perform a loop iteration on a hypothetical state <i:20, j:21>, after the iteration the invariant is broken.

#### A note on uPL array vs Python List and array

Using Python to express and check your pre-/post-conditions and loop-invariants has some distractive consequences. Obviously, Python is not the same as the theoretical language uPL from your Lecture Notes. The most apparent consequence for you is probably in dealing with arrays. In uPL an array is of infinite size, with indices go from -inf to +inf, so an expression like a[-1] won't crash in uPL. However, using STV-Checker means that uPL arrays are now represented either a Python list or a Numpy array. For a Numpy array, evaluating b[-1] will throw an exception. For a Python list s[-1] will also throw an exception, if s is empty, and otherwise you get its last element!

When preparing the exercises we try to be make the setup as close to uPL as possible. But it may still be the case that you may need a bit more detailed Python-level invariant than it would have been in pure uPL.
