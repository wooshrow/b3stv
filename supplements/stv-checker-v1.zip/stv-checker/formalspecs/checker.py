#
# Contain functions to check the correctness of pre- and post-conditions, 
# and to check loop invariants of a program.
# Few notes: 
#  * the checker assumes that the given program is correct.
#  * at the moment the checking is done through testing,
#    which mean that the checking is NOT guaranteed to be
#    complete.
#  * given test-cases are assumed to be type-correct. In other words,
#    we consider type-checking to be outside the scope of what a 
#    pre-/post-condition or invariant expresses. Note that for some
#    programming languages, notably C or even Python, this is may not be 
#    a safe assumption to make. 
#

class CheckingResult:
    verdict = None
    numberOfFails = 0

    def __str__(self):
        s = f"verdict:{self.verdict}, #fails:{self.numberOfFails}"
        return s
    
    def ABORT(self): self.verdict = "ABORT"
    def PASS(self): self.verdict = "PASS"
    def FAIL(self): self.verdict = "FAIL"
    def isABORT(self) -> bool : return self.verdict == "ABORT"
    def isPASS(self) -> bool  : return self.verdict == "PASS"
    def isFAIL(self) -> bool  : return self.verdict == "FAIL"

class Checker:
    """
    An object of this class bundles a program, its pre-condition, post-condition,
    and test suites to check them.

    Fields for pre- and post-conditions checking:

      name : the program name.
      program : the program.
      precond : the program's pre-condition.
      postcond : the program's post-condition.
      precondTests : a list of tests to check the pre-condition.
      postcondNegTests : a list of **negative** tests to test the post-condition.
      postcondPosTests: a list of **positive** tests to test the post-condition.
      silent: if True the checker will not emmit message to the console. Default: False.
      stopAtFirstViolation: if True the checker will stop at the first test that gives a violation. Default: False.

    Additional fields for loop-invariant checking:

      varnames : A list of variable names that form the program state, e.g. ["r","i"].
      inv : the loop invanriant, represented a function from state to bool.
      stmtBefore : a statement that comes before the loop, represented as a function from state to state.
      stmtAfter : a statement that comes before the loop, represented as a function from state to state.
      loopGuard : the guard of the loop, represented a function from state to bool.
      loopBody : the statement that forms the loop's body, represented as a function from state to state.
      m : the termination metric, represented as a function from state to int.
      PinvTests : a list of states that are used to test the loop invariant. 

    Pre-condition tests: 
      
      every test is of the form (e,i) where i is a tuple of inputs for the program, 
      and e is the expected output of the pre-cond.

    Positive post-condition tests:

       every test is a tuple i of input. This will be given to the program, and 
       suppose the program produces an output r. The post-cond is expected to 
       accept this r. 

    Negative post-condition tests:  

      every test is a tuple [r,i1,12..] where i1,i2... is a list of inputs for the program, 
      and r is a hypothetically **wrong** output of the program. The post-cond is 
      expected to reject this r.

    Invariant tests:

       every test is a tuple (x,y,...) representing a particular state of the program. The tuple
       lists the values of all variables of the program.

    """

    program = None
    name = None
    precond = None
    postcond = None
    precondTests = []
    postcondNegTests = []
    postcondPosTests = []
    silent = False
    stopAtFirstViolation = False
    
    # fields for invariant-checking:
    varnames = []
    inv = None
    stmtBefore = None
    stmtAfter = None
    loopGuard = None
    loopBody = None
    m = None
    PinvTests = []

    def __init__(self,program,precond,postcond):
        self.program = program
        self.name = program.__name__
        self.precond = precond
        self.postcond = postcond

    def copyTestFrom(self, C2) :
        self.precondTests = C2.precondTests
        self.postcondPosTests = C2.postcondPosTests
        self.postcondNegTests = C2.postcondNegTests

    def printx(self,s):
        if not self.silent: print(s)
    
    def updateVerdict(self, R:CheckingResult) :
        if R.numberOfFails>0 : R.FAIL()
        else: R.PASS()

    def printVerdict(self, R:CheckingResult) :
        self.printx(f"|   ** #FAILS: {R.numberOfFails} " + ("Yay!" if R.isPASS() else "... not quite there yet."))
        self.printx ("+--------")

    def checkPrecond(self) -> CheckingResult : 
        """
        Run the pre-condition tests to check the pre-condition that you attached 
        to the checker.
        """
        S = self 
        S.printx(f"|>> Checking your pre-condition of {S.name}... {len(S.precondTests)} tcs")
        S.printx(f"+--")
        R = CheckingResult()

        for (expectedJudgement,tc) in S.precondTests:
            try:
                judgement = S.precond(*tc)
            except:
                judgement = "the precond threw an error!"
            if not isinstance(judgement,bool):
                S.printx(f"|  ## ABORTING: a pre-condition should give a True/False judgement!!")
                S.printx(f"|     (tc is {S.name}{tc}, your pre-cond gives {judgement})")
                R.ABORT()
                return R
            if judgement != expectedJudgement:
                if expectedJudgement:
                    S.printx(f"|  ## tc {S.name}{tc} fails, your precond gives {judgement}")
                    S.printx(f"|     That input should be ACCEPTED! (expected: {expectedJudgement})")
                else:
                    S.printx(f"|  ## tc {S.name}{tc} fails, your precond gives {judgement}.")
                    S.printx(f"|     That input should be REJECTED! (expected: {expectedJudgement})")
                R.numberOfFails += 1

            if S.stopAtFirstViolation and R.numberOfFails>0 : break

        S.updateVerdict(R)
        S.printVerdict(R)
        return R        


    def checkPostcond(self) -> CheckingResult : 
        """
        Run the post-condition tests to check the post-condition that you attached
        to the checker.
        """
        S = self 
        R = CheckingResult()
        positive_postCondTests = [(True,  (S.program(*tc),) + tc) for tc in S.postcondPosTests]
        # for positive post-tests we add all positive precond tests:
        positive_postTests_additional1 = [ (True, (S.program(*tc),) + tc) for (r,tc) in S.precondTests if r==True]
        # we will also add negative pre-cond tests, turned positive:
        positive_postTests_additional2 = [ (True, (S.program(*tc[1:]),) + tc[1:]) for tc in S.postcondNegTests ]

        positive_postTests_ALL = positive_postTests_additional1 + positive_postTests_additional2 + positive_postCondTests

        negative_postcondTests = [(False,tc) for tc in S.postcondNegTests]

        # gathering all post-cond tests; duplicates are removed:
        ALL = negative_postcondTests + positive_postTests_ALL
        postTests_ALL = []
        for tc in ALL:
            if not (tc in postTests_ALL): postTests_ALL += [tc]

        S.printx(f"|>> Checking your post-condition of {S.name} ... {len(postTests_ALL)} tcs")
        S.printx(f"+--")

        for (expectedJudgement,tc) in postTests_ALL:
            #print(f">>> tc:{tc}, expected: {expectedJudgement}")
            try:
                judgement = S.postcond(*tc)
            except:
                judgement = "the postcond threw an error!"
            if not isinstance(judgement,bool):
                S.printx(f"|   ** ABORTING: a post-condition should give a True/False judgement!!")
                S.printx(f"|      (tc is {S.name}{tc[1:]} with retval={tc[0]}, your postcond gives {judgement})")
                R.ABORT()
                return R
            if judgement != expectedJudgement:
                if expectedJudgement: 
                    # positive test:
                    S.printx(f"|   ** tc {S.name}{tc[1:]} with retval={tc[0]}. Your post-cond gives {judgement}. Expected: {expectedJudgement} (the retval should be ACCEPTED)")
                else:
                    # negative test:
                    S.printx(f"|   ** tc {S.name}{tc[1:]} with hypothetical retval={tc[0]}. Your post-cond gives {judgement}.")
                    S.printx(f"|      Expected: {expectedJudgement} (the retval should be REJECTED)")
                R.numberOfFails += 1

            if S.stopAtFirstViolation and R.postCondCheckingNumberOfFails > 0 : break

        S.updateVerdict(R)
        S.printVerdict(R)
        return R    

    def showState(self,state):
        return "<" + ", ".join([ f"{vname}:{val}" for (vname,val) in zip(self.varnames,state) ]) + ">"
          
    def simulateLoop(self,*params):
        """
        Simulate the loop attached to this checker using params as input.
        """
        S = self
        S.printx(f"|>> Simulating {S.name}{params}")
        if S.stmtBefore is None:
            state = params
        else:
            S.printx( "|   * executing stmt before the loop")
            state  = S.stmtBefore(*params)

        try:
            invok = S.inv(*state)
        except Exception as e:
            S.printx(f"|   * inv threw an exception, state: {S.showState(state)}, exception:{e}")
            S.printx("+--------")
            raise e
           
        S.printx(f"|   * state: {S.showState(state)}, m:{S.m(*state)}, inv:{bool2holding(invok)}")
        S.printx( "|   > coming to the loop")
        k = 0
        while S.loopGuard(*state):
            k += 1
            try:
                state = S.loopBody(*state)
            except Exception as e:
                S.printx(f"|   > iter-{k}; loop body throws an exception! {e}")
                raise e
            try:
                invok = S.inv(*state)
                mval = S.m(*state)
            except Exception as e:
                S.printx(f"|   * inv or m threw an exception, state: {S.showState(state)}, exception:{e}")
                S.printx("+--------")
                raise e
            S.printx(f"|     > iter-{k}; state: {S.showState(state)}, m:{mval}, inv:{bool2holding(invok)}")
        S.printx( "|   * the loop exits")
        if S.stmtAfter is not None:
            try:
                S.printx( "|   * executing stmt after the loop")
                state = S.stmtAfter(*state)
            except Exception as e:
                S.printx(f"|   > the statement after the loop throws an exception! {e}")
                S.printx("+--------")
                raise e
        try:
            postOk = S.postcond(*state)
        except Exception as e:
            S.printx(f"|   * the post-cond threw an exception, state: {S.showState(state)}, exception:{e}")
            S.printx( "+--------")  
            raise e
        state_ = ", ".join([ f"{vname}:{val}" for (vname,val) in zip(S.varnames,state) ])
        S.printx(f"|   > state: {S.showState(state)}, m:{S.m(*state)}, post:{bool2holding(postOk)}")
        S.printx( "+--------")    

    
    def checkPinit(self) -> CheckingResult :
        """
        Check if the invariant is indeed established before we start the loop.
        
        More precisely we check {pre} stmt-before-loop {I}.
        
        This uses the tests from precondTests.
        """
        S = self 
        S.printx(f"|>> Checking if the inv of {S.name} is established at the start of the loop...")

        R = CheckingResult()

        tests = []
        for (v,params) in self.precondTests :
            try:
                precondOk = S.precond(*params)
            except Exception as e:
                S.printx(f"|   * precond threw an exception, state: {S.showState(params)}, exception:{e}")
                S.printx("+--------")
                R.ABORT()
                return R
            if precondOk:
                tests = [params] + tests

        if len(tests)==0 :
            S.printx(f"    BUT 0 relevant test is provided.")
            S.printx("+--------")
            R.ABORT()
            return R
        
        S.printx(f"|   * testing with {len(tests)} tcs ...")
        S.printx(f"+--")
        for params in tests:
            #print(f">>> {st}")
            try:
                if S.stmtBefore is None:
                    st2 = params
                else :
                    st2 = S.stmtBefore(*params)
                ok = S.inv(*st2)
                if ok != True:
                   S.printx(f"|   ** inv VIOLATED! Call is {S.name}{params}")
                   S.printx(f"|                    state at the loop: {S.showState(st2)}")
                   R.numberOfFails += 1
                #else:
                   #print(f">>> {st}")
            except:
                S.printx(f"|   ** The stmt before the loop or the inv threw an exception!! Call is {S.name}{params}")
                R.numberOfFails += 1

            if S.stopAtFirstViolation and R.numberOfFails > 0 : break

        S.updateVerdict(R)
        S.printVerdict(R)
        return R

    def getInvRelevantTests(self,additionalCond) : 
        """
        Obtain all states in PinvTests that satisfy inv and the given additional
        condition (which is either g or ~g).
        The function also checks if the inv throws an exception on those states.
        """
        tests = []
        for st in self.PinvTests :
            # ok a bit contrived logic to check inv and cond, due to possibily that
            # each may throw an exception
            invOk = None
            condOk = None
            E = None
            try:
                invOk = self.inv(*st) 
            except Exception as e:
                E = e
            
            try:
                condOk = additionalCond(st)
            except Exception as e:
                E = e
            
            if invOk==False or condOk == False :
                continue
            
            if invOk==True and condOk == True:
                tests = [st] + tests
            else: 
                # well then exception has been thrown, neither cond reject
                self.printx(f"|   * loop-guard or inv threw an exception, state: {self.showState(st)}, exception:{E}")
                self.printx(f"      Likely cause: the state is illegal but your inv is not strong enough to exclude it.")
                self.printx(f"      Repair suggestion: strengthen your inv.")
                self.printx("+--------")
                return None

        return tests

    def checkPinv(self) -> CheckingResult :
        """
        Check that the inv is restored after every iteration.

        That is, we check: {I and g} loop-body {I}

        This uses PinvTests.
        """
        S = self 
        S.printx(f"|>> Checking if the inv of {S.name} is restored after every iteration...")

        R = CheckingResult()
        # filter the tests to pick only those satisfying I and g
        tests = S.getInvRelevantTests(lambda z: S.loopGuard(*z))
        if tests is None:
            R.ABORT()
            return R
        
        if len(tests)==0 :
            S.printx(f"    BUT 0 relevant test is provided.")
            S.printx("+--------")
            R.ABORT()
            return R

        S.printx(f"|   * testing with {len(tests)} tcs ...")
        S.printx(f"+--")
        for st in tests:
            #print(f">>> {st}")
            try:
                st2 = S.loopBody(*st)
                ok = S.inv(*st2)
                if ok != True:
                   S.printx(f"|   ** inv VIOLATED! state before: {S.showState(st)}")
                   S.printx(f"|                    state after : {S.showState(st2)}")
                   R.numberOfFails += 1
            except:
                S.printx(f"|   ** The loop-body or the inv threw an exception!! state before: {S.showState(st)}")
                R.numberOfFails += 1

            if S.stopAtFirstViolation and R.numberOfFails > 0 : break

        S.updateVerdict(R)
        S.printVerdict(R)
        return R
    

    def checkPexit(self) -> CheckingResult :
        """
        Check that if the loop terminates with inv still holds, the program
        will establish its post-condition.

        That is, we check: {I and ~g} stmt-after-loop {post}

        This uses PinvTests.
        """
        S = self 
        S.printx(f"|>> Checking if on termination, the inv of {S.name} implies the post-cond ...")
       
        R = CheckingResult()
        # filter the tests to pick only those satisfying I and ~g
        tests = S.getInvRelevantTests(lambda z: not S.loopGuard(*z))

        if tests is None:
            R.ABORT()
            return R
        
        if len(tests)==0 :
            S.printx(f"    BUT 0 relevant test is provided.")
            S.printx("+--------")
            R.ABORT()
            return R

        S.printx(f"|   * testing with {len(tests)} tcs ...")
        S.printx(f"+--")
        for st in tests:
            #print(f">>> {st}")
            try:
                if S.stmtAfter is None:
                    st2 = st
                else:
                    st2 = S.stmtAfter(*st)
                ok = S.postcond(*st2)
                if ok != True:
                   S.printx(f"|   ** postcond VIOLATED! state at the loop exit: {S.showState(st)}")
                   S.printx(f"|                         state at the post-cond: {S.showState(st2)}")
                   R.numberOfFails += 1
                #else:
                   #print(f">>> {st}")
            except:
                S.printx(f"|   ** The stmt after the loop or the post-cond threw an exception!! state before: {S.showState(st)}")
                R.numberOfFails += 1

            if S.stopAtFirstViolation and R.numberOfFails > 0 : break

        S.updateVerdict(R)
        S.printVerdict(R)
        return R


    def checkPTC1(self) -> CheckingResult :
        """
        Check that every iteration decreases the termination metric.

        That is, we check: {I and g} C:=m ; loop-body {m<C}

        This uses PinvTests.
        """
        S = self 
        S.printx(f"|>> Checking if every iteration decreases the termination metric...")

        R = CheckingResult()
        # filter the tests to pick only those satisfying I and g
        tests = S.getInvRelevantTests(lambda z: S.loopGuard(*z))
        if tests is None:
            R.ABORT()
            return R
        if len(tests)==0 :
            S.printx(f"    BUT 0 relevant test is provided.")
            S.printx("+--------")
            R.ABORT()
            return R

        S.printx(f"|   * testing with {len(tests)} tcs ...")
        S.printx(f"+--")
        for st in tests:
            #print(f">>> {st}")
            try:
                m0 = S.m(*st)
                st2 = S.loopBody(*st)
                m1 = S.m(*st2)
                if m1 >= m0:
                   S.printx(f"|   ** m does NOT decrease! state before: {S.showState(st)} , m:{m0}")
                   S.printx(f"|                           state after : {S.showState(st2)}, m:{m1}")
                   R.numberOfFails += 1
            except:
                S.printx(f"|   ** The loop-body or m threw an exception!! state before: {S.showState(st)}")
                R.numberOfFails += 1

            if S.stopAtFirstViolation and R.numberOfFails > 0 : break

        S.updateVerdict(R)
        S.printVerdict(R)
        return R
    

    def checkPTC2(self) -> CheckingResult :
        """
        Check that the termination metric has a lower bound.

        That is, we check: I and g ==> m>0

        This uses PinvTests.
        """
        S = self 
        S.printx(f"|>> Checking that the termination metric has a lower bound (0)...")

        R = CheckingResult()
        # filter the tests to pick only those satisfying I and g
        tests = S.getInvRelevantTests(lambda z: S.loopGuard(*z))
        if tests is None:
            R.ABORT()
            return R
        if len(tests)==0 :
            S.printx(f"    BUT 0 relevant test is provided.")
            S.printx("+--------")
            R.ABORT()
            return R

        S.printx(f"|   * testing with {len(tests)} tcs ...")
        S.printx(f"+--")
        for st in tests:
            #print(f">>> {st}")
            try:
                m0 = S.m(*st)
                #print(f">>> {st}, m={m0}")
                if m0 <= 0:
                   S.printx(f"|   ** m drops to 0 or lower! state: {S.showState(st)} , m:{m0}")
                   R.numberOfFails += 1
            except:
                S.printx(f"|   **  m threw an exception!! state before: {S.showState(st)}")
                R.numberOfFails += 1

            if S.stopAtFirstViolation and R.numberOfFails > 0 : break

        S.updateVerdict(R)
        S.printVerdict(R)
        return R
    

def bool2holding(b):
    return "holds" if b else "VIOLATED"