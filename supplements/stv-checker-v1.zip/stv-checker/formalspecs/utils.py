def implies(p:bool, q:bool) -> bool : 
    """
    Returns true if p implies q, else false.
    """
    return not p or q

