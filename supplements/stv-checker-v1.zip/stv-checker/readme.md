# STV-Checker

This tool is meant to help you checking your solutions on

  * exercises about **formalizing pre- and post-conditions**
  * exercises where you have to **come up with loop invariants**. (currently still being developd)

With this tool you can get almost instant feedback on the aforementioned two learning goals. We hope that this can improve your learning.  

First, few remarks about what this tool is NOT, and what the tool limitation is:

* To make your pre-/post-conditions and invariants checkable by STV-Checker, you need to formulate them as Python functions. **For actual submission, submit Mathematical formulas. Don't submit Python functions!**
* The tests you write with this STV-Checker are for you. Don't submit them to us 😀
* STV-Checker is not a tool to check a formal proof.
* STV-Checker uses _testing_. So, when your formulas pass its checking, this is not a waterproof guarantee. Feel free to add more tests though.
* In our exercises type-checking is assumed to be delegated to the Compiler or Interpreter. Primitive types like int are assumed to be non-null/None. So, you don't have to incorporate such checking in your pre- and post-conditions. Do keep in mind that in a real life setup these may not be a safe assumption (e.g. if we program in C, or in even in Python).


#### Requirements

* Tested on Python 3.12. Higher version should work.
* Require [numpy](https://pypi.org/project/numpy/) to borrow numpy-array in some exercises.
* Require [pytest](https://docs.pytest.org/en/stable/). Tested on 7.4.4; higher version should work.

## Where are the exercises

* `exercises_specs`: exercises on pre- and post-conditions.
* `exercises-invs`: exercises on loop invariants (TODO)

## Example: pre-/post-cond checking

Exercises on writing pre- and post-conditions are in `./exercises_specs`. Exercises on writing loop invariants are in `./exercises_invs`. For example one of the execises on pre- and post-conditions is `MIN.py` which looks like this:

```python
def myMIN(x:int, y:int)-> int :
    """
    This program returns the minimum of the two integers.
    """
    dif = y - x
    return y if dif <=0 else x

# You can Python-formulate the pre-condition here.
def precondition(x:int, y:int) -> bool :
    return ...

# You can Python-formulate the post-condition here.
#   * Use only logical and arithmetic operators.
#   * Don't use assignment.
#   * Don't use Python native "min"
#   * 'retval' represents the return value of your program.
def postcondition(retval:int, x:int, y:int) -> bool :
    return ...
```

The program to consider is `myMIN`. Its doc-string documentation states its _intended_ functionality in natural language description. In our exercises, the provided code/implementation should correctly implement its intent (though in real life this is not always the case, of course).

You write your pre- and post-conditions in the functions `precondition` and `postcondition`. For example for the post-condition of `myMIN` it could be:

```python
def postcondition(retval:int, x:int, y:int) -> bool :
    return retval <= x and retval <=y
```

That post-condition is not perfect btw; you should improve it 😀.

#### The checker and the tests

The file `MIN.py` also creates an instance of STV-Checker:

`checker = Checker(myMIN,precondition,postcondition)`

Subsequent lines add tests for checking your pre- and post-condition. You don't really need to know this aspect in details, but in case you are curious, there are three group of tests:

   * `checker.precondTests = [ (e1,z1), (e2,z2), ...]`. This specifies tests to check your pre-condition. Every test is a pair _(e,z)_ where _z_ is a tuple of inputs for the program (so, it would be two integers for `MIN`) and _e_ is the expected judgement of the pre-condition on _z_. This judgement is a boolean (_true_ or _false_). _True_ if _z_ is by intent a valid input for the program, and _false_ if _z_ represents an illegal input which should be rejected.
   * `checker.postcondPosTests = [z1, z2, ...]`. This specifies tests to check your post-condition. Every test is a tuple _z_ of inputs for the program (so, again, it would be two integers for `MIN`). Suppose the program returns _r_ when given _z_ as input. Since in our exercises the programs are assumed to be correct, _r_ is a correct output. So your post-condition is expected to give a _true_ judgement on this pair _(r,z)_.
   * `checker.postcondNegTests = [(r1,i1_1,i1_2,...), (r2,i2_1,i2_2,...), ...]`. This specifies **negative tests** to check your post-condition. These tests are important as only positive tests are not good enough. Each negative test is a list _z_ where the first element, _r_, represents return value and the remaining part of _z_, let's call it _z'_, represents inputs for the program. In particular, _r_ represents a hypothetically wrong return value when the proram is given _z'_ as inputs. Your post-condition should give the judgement _false_ on _(r,z')_.  



### Running the pre-/post-cond checker

A recommended way to run the checker is from a test-file. For our example problem `MIN.py`, create a file called e.g. `test_MIN.py`. In any case, the file name should start with the word _test_. Put this file in the directory `./tests`.

Put this content in that file:

```python
from exercises_specs import MIN

def test_pre():
   R = MIN.checker.checkPrecond()
   assert R.verdict == "PASS"

def test_post():
   R = MIN.checker.checkPostcond()
   assert R.verdict == "PASS"
```

So... we start by importing your `MIN.py` (that contains your solution pre- and post-condition). This file already created an instance of the STV-Checker and attached  proper tests to the checker.

We invoke the checker in the two test-functions `test_pre()` and `test_post()`.

To actually run the check we now need to run `test_MIN.py`. We do that using the unit testing tool **pytest**. As a note: Python has two popular unit testing tools: **unittest** and pytest. Which one is better is up for debate. For STV-Checker I just choose pytest.

Anyway, to run the checker, you first need to open a command line shell, e.g. Bash (Linux) or PowerShell (Windows). In the shell prompt, go to directory `tests` of the project (use the `cd` command).

From the command line, invoke pytest:

`pytest -v -s your-test-file`

E.g. in our example the test-file is `test_MIN.py`.
   * `-s` : you will be able to see the messages printed by STV-Checker
   * `-v` : verbose mode. Pytest will tell you which test fails.

You will see something like this messaging produced by the Checker:

```
test_MIN.py::test_post
|>> Checking your post-condition of myMIN ... 14 tcs
+--
|   ** tc myMIN(1, 2) with hypothetical retval=-9. Your post-cond gives True.
|      Expected: False (the retval should be REJECTED)
|   ** tc myMIN(0, 0) with hypothetical retval=-9. Your post-cond gives True.
....
```

This shows that the post-condition that we wrote before for `MIN` is not good yet. It reports that if hypothetically `MIN(1,2)` returns -9, the post-condition is ok with it. Obviously, -9 should be rejected, so we should fix that post-condition.

If you turned on that `-v` (verbose-mode) option, you additionally see pytest further information on failing tests e.g.:

```
def test_post():
   R = MIN.checker.checkPostcond()
>      assert R.verdict == "PASS"
E      AssertionError: assert 'FAIL' == 'PASS'
E        - PASS
E        + FAIL
```

It shows which test and which assertion fail, and why.

If you want to just run a particular test-function in a test-file (so, no all all the test-functions), you can do:

`pytest -v -s test-file::test-function-name`

### Math STV Notation vs Python

For writing formal specifications your reference notation is the Math notation as in STV Lecture Notes. But for using this Checker, which does not parse STV Math notation, you will have to express your ideas in Python to allow the STV-Checker to check them. Below are examples of key Math notations and how they can be expressed in Python.

|  | STV-Math | Python | Notes |
|--|--|--|--|
| conjunction | p ∧ q | p and q |
| disjunction | p ∨ q | p or q |
| negation | ¬ x>y | not x > y |
| implication | p ⇒ q | no Python counter part. You can define one, **def** implies(p,q): **return** not p or q |
| equality check | x = y | x == y |
| forall | (∀i : 0≤i<#a-1 : a[i]≤a[i+1]) | **all**([a[i] <= a[i+1] **for** i in **range**(a,len(a)-1)]) | a is an array
| exists | (∃i : 0≤i<#a-1 : a[i]=a[i+1]) | **any**([a[i] == a[i+1] **for** i in **range**(a,len(a)-1)]) | a is an array |

Formulas involving array can be a bit tricky. Evaluating e.g. a[k]=0 ∧ k≥0 in STV-Math on a state where k is -1 would result in false.
In Python that expression will crash (assuming a is represented as e.g. a Numpy array), though not if you re-order the formulation to
k>=0 and a[k]==0.

| formula | state | evaluation result |
|--|--|--|
STV-Math: a[k]=0 ∧ k≥0| state where k is -1 | false |
STV-Math: k≥0 ∧ a[k]=0 | state where k is -1 | false |
Python: a[k]==0 and k>=0 | state where k is -1, a is a (Numpy) array | crash |
Python: k>=0 and a[k]==0 | state where k is -1, a is ... does not matter| false |




### Something extra: STV-Checker with Hypothesis

This section is only if you fancy something 'extra'. You don't need this for the main learning goals mentioned at the start of this page.

[**Hypothesis**](https://pypi.org/project/hypothesis/) is an automated test-inputs generator for Python, comparable to Haskell's QuickCheck. You can use it to generate more tests to check your post-conditions. The learning goal here is simply to introduce you to Hypothesis. It's not an exam material, and you can safely skip this part.

Only positive tests for post-conditions can be generated. Negative tests and tests for pre-conditions require a 'ground truth' to generate.

We first import `hypothesis` and we import `MIN.py` which contains your pre- and post-conditions:

```python
from hypothesis import given, strategies as st
from exercises_specs import MIN
```
Next, we create a test. In the example below we will test your post-condition that you wrote in `MIN.py`. Below, the test-function is named `test_postcond`. Notice that it is a **parameterized test**, taking _x_ and _y_ are parameters. The `@given` attribute specifies that these _x_ and _y_ are to be generated by Hypothesis.

```python
@given(st.integers(-3,3), st.integers(-3,3))
def test_postcond_with_hyp(x,y):
    S = MIN.checker
    if S.precond(x,y):
        # invoking the program only makes sense on inputs that
        # satisfy the pre-cond:
        retval = S.program(x,y)
        assert S.postcond(retval,x,y)
```

You can run the test like this:


`pytest -v -s --hypothesis-verbosity=verbose --hypothesis-show-statistics test-file.py::test_postcond_with_hyp`

   * `--hypothesis-show-statistics` will show you how many tests were generated
   * `--hypothesis-verbosity=verbose` will show you which tests were generated

## Example: loop-invariant and termination checking

[See inv-readme.md](./inv-readme.md)

## Other things

### Debugging

Some random info useful for debugging.

* Running an exercise-file directly from CLI. From project root, e.g.: `python -c "import exercises_specs.MIN"`
`

### Issues

Please let me know if you find issues. For example if the Checker fails to reject an incorrect pre- or post-condition.
