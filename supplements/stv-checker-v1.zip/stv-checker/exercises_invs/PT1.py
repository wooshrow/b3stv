from formalspecs.checker import Checker

def PT1(k:int) -> int :
    """
    Consider the program below with a loop. The pre- and post-conditions are
    annotated below. Come up with an invariant and a termination metric that 
    would prove that the program terminates with the said post-cond.

    You can check your candidate invariant and termination metric with the 
    provided checker below. Just keep in mind that the checker checks with
    testing; it does not produce a formal proof for you.
    """
    # pre is k==1
    while not (k==10) :
        if k==1 :
            k = 0
        else :
            k += 2
    # post is k==10
    return k

# define here your invariant
def inv(k:int) -> bool:
     return 0 <= k  # a dummy inv

# define here your termination metric
def m(k:int) -> int : 
     return k # a dummy m

def precond(k:int) -> bool : return k==1
def postcond(k:int) -> bool: return k==10

# create an instance of stv-checker:
checker = Checker(PT1,precond,postcond)

# configuring the checker:
checker.inv = inv
checker.m   = m

def loopBody(k:int) :
    if k==1 :
            k = 0
    else :
            k += 2
    return (k,)

checker.varnames  = ["k"]
checker.loopBody  = loopBody
checker.loopGuard = lambda k: not(k == 10)

# specifying the tests:
checker.precondTests = [(True,(1,))]
checker.PinvTests = [ (k,) for k in range(-2,12)] 

# you can simulate the loop e.g. like this:
#checker.simulateLoop(1)

#checker.checkPinit()
#checker.checkPinv()
#checker.checkPexit()
#checker.checkPTC1()
#checker.checkPTC2()


