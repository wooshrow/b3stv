from formalspecs.checker import Checker

def MUL(X:int, Y:int) -> int :
    """
    Consider the program below with a loop. It is the A'h-mose algorithm
    to efficiently calculate X*Y. In hardware multiplication or division
    by two can be efficiently done with a single bits-shifting instruction.
    
    Come up with an invariant and a termination metric that 
    would prove that the program terminates with the said post-cond.

    You can check your candidate invariant and termination metric with the 
    provided checker below. Just keep in mind that the checker checks with
    testing; it does not produce a formal proof for you.
    """
    # pre: X>=0 and Y>=0
    x = X
    y = Y
    z = 0
    while not (x == 0) :
        if x%2 == 1:
            z = z+y
            x = x - 1
        else :
            y = y*2
            x = x/2
    # post: z = X*Y
    return z

# define here your invariant
def inv(X:int,Y:int,x:int,y:int,z:int) -> bool:
     return 0 <= x  # this inv is not good enough, fix it

# define here your termination metric
def m(X:int,Y:int,x:int,y:int,z:int) -> int : 
     return y # a dummy m

def precond(X:int, Y:int) -> bool                  : return X>=0 and Y>=0
def postcond(X:int,Y:int,x:int,y:int,z:int) -> bool: return z == X*Y

# create an instance of stv-checker:
checker = Checker(MUL,precond,postcond)

# configuring the checker:
checker.inv = inv
checker.m   = m

def stmtBefore(X:int,Y:int) :
    x = X
    y = Y
    z = 0
    return (X,Y,x,y,z)

def loopBody(X:int,Y:int,x:int,y:int,z:int) :
    if x%2 == 1:
        z = z+y
        x = x - 1
    else :
        y = y*2
        x = x/2
    return (X,Y,x,y,z)

checker.varnames  = ["X","Y","x","y","z"]
checker.stmtBefore = stmtBefore
checker.loopBody  = loopBody
checker.loopGuard = lambda X,Y,x,y,z: not(x == 0)

# specifying the tests:
checker.precondTests = [(True,(0,1)), (True,(0,0)), (True,(3,8)), (True,(3,7)), (True,(8,3))]
checker.PinvTests = [ (X,Y,x,y,z) 
                      for X in range(-1,6) 
                      for Y in range (-1,6)
                      for x in range (-1,6)
                      for y in range (-1,6)
                      for z in range (-1,6)] 

# you can simulate the loop e.g. like this:
#checker.simulateLoop(4,3)

#checker.checkPinit()
#checker.checkPinv()
#checker.checkPexit()
#checker.checkPTC1()
#checker.checkPTC2()


