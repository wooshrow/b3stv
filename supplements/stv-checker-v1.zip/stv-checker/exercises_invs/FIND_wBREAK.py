from formalspecs.checker import Checker
import numpy as np
import numpy.typing as npt

def smarterFIND(x:int, N:int,  a:npt.NDArray[int]) -> bool :
    """
    This program checks if a occurs in the array segment a[0..N). The pre-
    and post-conditions are annotated as comments below.
    
    Notice the loop breaks early when x has been found, or when it concludes
    that it won't appear in the remaining part of a.

    Come up with an invariant for the program's loop and a termination metric 
    that would prove that the program terminates with the said post-cond.

    You can check your candidate invariant and termination metric with the 
    provided checker below. Just keep in mind that the checker checks with
    testing; it does not produce a formal proof for you.
    """
    # pre: 0<=N<=#a, a[0..N)] is ascendinly sorted
    found = False
    i = 0
    while i < N and not found and a[i]<=x :
        found = found or (a[i] == x)
        i += 1
    # found is true if and only if x is in the segment a[0..N)
    return found

# define here your invariant
def inv(x:int,N:int,a:npt.NDArray[int],i:int,found:bool) -> bool:
     I1 = N<=len(a) and 0<=i
     # let's also thread this over to your inv, since you can't pass
     # global assumptions to the STV-checker. It says that a is sorted,
     # since the program does not update a, it is safe to add this:
     I2 = all(a[i] <= a[i+1] for i in range(0,N)) 
     return I1 and I2 # but this is still not good enough; fix it
     # ordering sensitive btw, I1 first then I2

# define here your termination metric
def m(x:int,N:int,a:npt.NDArray[int],i:int,found:bool) -> int : 
     return None # a dummy m

def precond(x:int,N:int,a:npt.NDArray[int]) -> bool  : 
    return 0<=N and N<=len(a) and all(a[i] <= a[i+1] for i in range(0,N-1))
def postcond(x:int,N:int,a:npt.NDArray[int],i:int,found:bool) -> bool: 
    return found == any([a[k]==x for k in range(0,N)])

# create an instance of stv-checker:
checker = Checker(smarterFIND,precond,postcond)

# configuring the checker:
checker.inv = inv
checker.m   = m

def stmtBefore(x:int,N:int,a:npt.NDArray[int]) :
    found = False
    i = 0
    return (x,N,a,i,found)

def loopBody(x:int,N:int,a:npt.NDArray[int],i:int,found:bool) :
    if i<0 or i>len(a):
        raise IndexError(f"trying to access an array outside its valid indices: {i}")
    found = found or (a[i] == x)
    i += 1
    return (x,N,a,i,found)

def loopGuard(x:int,N:int,a:npt.NDArray[int],i:int,found:bool) :
    if i<0 or i>len(a):
        raise IndexError(f"trying to access an array outside its valid indices: {i}")
    return i < N and not found and a[i]<=x 

checker.varnames  = ["x","N","a","i","found"]
checker.stmtBefore = stmtBefore
checker.loopBody  = loopBody
checker.loopGuard = loopGuard

# specifying the tests:
checker.precondTests = [(True,(0,0,np.array([]))), 
                        (True,(0,0,np.array([1,0,2]))),
                        (False,(0,-1,np.array([1,0,2]))),
                        (True,(0,1,np.array([1,0,2]))),
                        (True,(0,3,np.array([-1,0,2]))),
                        (False,(0,3,np.array([1,0,2]))),
                        (True,(9,3,np.array([-1,0,2]))),
                        (False,(9,3,np.array([1,0,2]))),
                        (False,(0,4,np.array([0,0,2]))),
                        (False,(0,1,np.array([])))
                        ]
checker.PinvTests = [ (x,N,a,i,found) 
                      for x in [0,9] 
                      for N in range (-1,4)
                      for a in [np.array([]), np.array([0,1]), np.array([1,0,1]), 
                                np.array([-1,-1,0]),
                                np.array([-1,2,5]) ]
                      for i in range (-1,5)
                      for found in [True,False]] 

# you can simulate the loop e.g. like this:
#checker.simulateLoop(0,3,np.array([-1,-1,0,-2]))

#checker.checkPinit()
#checker.checkPinv()
#checker.checkPexit()
#checker.checkPTC1()
#checker.checkPTC2()


