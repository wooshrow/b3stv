from formalspecs.checker import Checker

def P1(i:int, j:int) -> tuple[int,int] :
    """
    Consider the program below with a loop. The pre- and post-conditions are
    annotated below. Come up with an invariant and a termination metric that 
    would prove that the program terminates with the said post-cond.

    You can check your candidate invariant and termination metric with the 
    provided checker below. Just keep in mind that the checker checks with
    testing; it does not produce a formal proof for you.
    """
    # pre is i==2 and j==20
    while i<j :
        j = j-2
        i += 1
    # post is j==i
    return (i,j)

# define here your invariant
def inv(i:int, j:int) -> bool:
     return i <= j  # just this is not enough

# define here your termination metric
def m(i:int, j:int) -> int : 
     return i # a dummy m

def precond (i:int, j:int) -> bool : return i==2 and j==20
def postcond(i:int, j:int) -> bool : return j==i

# create an instance of stv-checker:
checker = Checker(P1,precond,postcond)

# configuring the checker:
checker.inv = inv
checker.m   = m

def loopBody(i:int, j:int) :
    j = j - 2
    i += 1
    return (i,j)

checker.varnames  = ["i","j"]
checker.loopBody  = loopBody
checker.loopGuard = lambda i,j: i<j

# specifying the tests:
checker.precondTests = [(True,(2,20))]
checker.PinvTests = [ (i,j) for i in range(-2,22) for j in range (-2,22)] 

# you can simulate the loop e.g. like this:
#checker.simulateLoop(2,20)

#checker.checkPinit()
#checker.checkPinv()
#checker.checkPexit()
#checker.checkPTC1()
#checker.checkPTC2()


