from formalspecs.checker import Checker
import numpy as np
import numpy.typing as npt

def FIND(x:int, N:int,  a:npt.NDArray[int]) -> bool :
    """
    This program checks if a occurs in the array segment a[0..N). The pre-
    and post-conditions are annotated as comments below.
    
    Come up with an invariant for the program's loop and a termination metric 
    that would prove that the program terminates with the said post-cond.

    You can check your candidate invariant and termination metric with the 
    provided checker below. Just keep in mind that the checker checks with
    testing; it does not produce a formal proof for you.
    """
    # pre: 0<=N<=#a 
    found = False
    i = 0
    while i < N :
        found = found or (a[i] == x)
        i += 1
    # post: found is true if and only if x is in the segment a[0..N)
    return found

# define here your invariant
def inv(x:int,N:int,a:npt.NDArray[int],i:int,found:bool) -> bool:
     return N<=len(a) and 0<=i # this not good enough

# define here your termination metric
def m(x:int,N:int,a:npt.NDArray[int],i:int,found:bool) -> int : 
     return None # a dummy m

def precond(x:int,N:int,a:npt.NDArray[int]) -> bool  : return 0<=N and N<=len(a)
def postcond(x:int,N:int,a:npt.NDArray[int],i:int,found:bool) -> bool: 
    return found == any([a[k]==x for k in range(0,N)])

# create an instance of stv-checker:
checker = Checker(FIND,precond,postcond)

# configuring the checker:
checker.inv = inv
checker.m   = m

def stmtBefore(x:int,N:int,a:npt.NDArray[int]) :
    found = False
    i = 0
    return (x,N,a,i,found)

def loopBody(x:int,N:int,a:npt.NDArray[int],i:int,found:bool) :
    if i<0 or i>len(a):
        raise IndexError(f"trying to access an array outside its valid indices: {i}")
    found = found or (a[i] == x)
    i += 1
    return (x,N,a,i,found)

checker.varnames  = ["x","N","a","i","found"]
checker.stmtBefore = stmtBefore
checker.loopBody  = loopBody
checker.loopGuard = lambda x,N,a,i,found: i < N

# specifying the tests:
checker.precondTests = [(True,(0,0,np.array([]))), 
                        (True,(0,0,np.array([1,0,2]))),
                        (False,(0,-1,np.array([1,0,2]))),
                        (True,(0,1,np.array([1,0,2]))),
                        (True,(0,3,np.array([1,0,2]))),
                        (True,(9,3,np.array([1,0,2]))),
                        (False,(0,4,np.array([1,0,2]))),
                        (False,(0,1,np.array([])))
                        ]
checker.PinvTests = [ (x,N,a,i,found) 
                      for x in [0,9] 
                      for N in range (-1,4)
                      for a in [np.array([]), np.array([0,1]), np.array([1,0,1]) ]
                      for i in range (-1,5)
                      for found in [True,False]] 

# you can simulate the loop e.g. like this:
#checker.simulateLoop(0,3,np.array([1,1,0,2]))

#checker.checkPinit()
#checker.checkPinv()
#checker.checkPexit()
#checker.checkPTC1()
#checker.checkPTC2()


