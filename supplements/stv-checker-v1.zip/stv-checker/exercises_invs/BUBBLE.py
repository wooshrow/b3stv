from formalspecs.checker import Checker
import numpy as np
import numpy.typing as npt

def BUBBLE(N:int,  a:npt.NDArray[int]) -> bool :
    """
    The following program traverses an array a from a[0] to a[N-1],
    with N ≥ 1. If it finds that an element a[i] is greater than its next
    neighbour a[i+1], it swaps the two elements. This way, once the loop
    terminates, no element in a positioned at an index less than N-1 is greater
    than a[N-1]. To put it differently, the program 'bubbles' the largest
    element in a[0..N) to the position N-1.

    Come up with an invariant for the program's loop and a termination metric
    that would prove that the program terminates with the said post-cond.

    You can check your candidate invariant and termination metric with the
    provided checker below. Just keep in mind that the checker checks with
    testing; it does not produce a formal proof for you.
    """
    # pre: 1<=N<=#a
    i = 0
    while not (i == N-1) :
        if a[i] > a[i+1] :
            tmp = a[i]
            a[i] = a[i+1]
            a[i+1] = tmp
        i += 1
    # all elements in a are <= a[N-1]
    return a

# define here your invariant
def inv(N:int,a:npt.NDArray[int],i:int) -> bool:
     return 1<=N and N <= len(a) # this not good enough

# define here your termination metric
def m(N:int,a:npt.NDArray[int],i:int) -> int :
     return None # a dummy m

def precond(N:int,a:npt.NDArray[int]) -> bool  : return 1<=N and N<=len(a)
def postcond(N:int,a:npt.NDArray[int],i:int) -> bool:
    return all([a[k] <= a[N-1] for k in range(0,N)])

# create an instance of stv-checker:
checker = Checker(BUBBLE,precond,postcond)

# configuring the checker:
checker.inv = inv
checker.m   = m

def stmtBefore(N:int,a:npt.NDArray[int]) :
    i = 0
    return (N,a,i)

def loopBody(N:int,a:npt.NDArray[int],i:int) :
    if i<0 or i>len(a):
        raise IndexError(f"trying to access an array outside its valid indices: {i}")
    # we'll do the update on a copy of a
    a = np.copy(a)
    if a[i] > a[i+1] :
            tmp = a[i]
            a[i] = a[i+1]
            a[i+1] = tmp
    i += 1
    return (N,a,i)

checker.varnames  = ["N","a","i"]
checker.stmtBefore = stmtBefore
checker.loopBody  = loopBody
checker.loopGuard = lambda N,a,i : not (i == N-1)

# specifying the tests:
checker.precondTests = [(False,(0,np.array([]))),
                        (False,(0,np.array([1,0,2]))),
                        (True ,(1,np.array([1,0,2]))),
                        (True ,(2,np.array([1,0,2]))),
                        (True ,(3,np.array([1,0,2]))),
                        (False,(4,np.array([1,0,2]))),
                        (True,(3,np.array([2,0,1]))),
                        (True,(2,np.array([0,2,1])))
                        ]
checker.PinvTests = [ (N,a,i)
                      for N in range (-1,5)
                      for i in range (-2,6)
                      for a in [np.array([0]),
                                np.array([9,0,2]),
                                np.array([0,9,2]),
                                np.array([0,9,10]) ]
                      ]

# you can simulate the loop e.g. like this:
#checker.simulateLoop(3,np.array([9,1,0]))

#checker.checkPinit()
#checker.checkPinv()
#checker.checkPexit()
#checker.checkPTC1()
#checker.checkPTC2()
