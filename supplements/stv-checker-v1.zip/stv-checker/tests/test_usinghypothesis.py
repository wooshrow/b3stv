from hypothesis import given, strategies as st
from tests import test_prepost_checker

@given(st.integers(-3,3), st.integers(-3,3))
def test1(x,y):
    S = test_prepost_checker.checker0
    if S.precond(x,y):
        # invoking the program only make sense on inputs that
        # satisfy the pre-cond:
        retval = S.program(x,y)
        assert S.postcond(retval,x,y)
