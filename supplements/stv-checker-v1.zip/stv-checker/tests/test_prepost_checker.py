import copy
from formalspecs.checker import (Checker, CheckingResult)

def myMIN(x:int, y:int)-> int :
    dif = y - x 
    return y if dif <=0 else x

def precond(x:int, y:int) -> bool :
    return True

def postcond(retval:int, x:int, y:int) -> bool :
    return (retval==x or retval==y) and (retval <= x and retval <= y)


precondTests = [ (True,(1,2)), (True,(-1,-2)), (True,(0,0)) ]
postcondNegTests = [(-9,1,2),(-9,0,0),(2,-1,2),(2,2,0),(0,1,1)]
postcondPosTests = [(-1,-2),(-1,1),(0,0),(1,1),(1,9),(9,2)]

checker0 = Checker(myMIN,precond,postcond)
checker0.precondTests = precondTests
checker0.postcondNegTests = postcondNegTests
checker0.postcondPosTests = postcondPosTests 


def test_vs_correct_prepost():
    R = checker0.checkPrecond()
    assert R.verdict == "PASS"
    assert R.numberOfFails == 0
    R = checker0.checkPostcond()
    assert R.verdict == "PASS"
    assert R.numberOfFails == 0

def test_negative_precond_test():
    checker1 = copy.copy(checker0)
    checker1.precondTests = [ (True,(1,2)), (False,(-1,-2)), (True,(0,0)) ]
    R = checker1.checkPrecond()
    assert R.verdict == "FAIL"
    assert R.numberOfFails == 1

def test_wrong_precond():
    checker1 = copy.copy(checker0)
    checker1.precond = lambda x,y : False
    R = checker1.checkPrecond()
    assert R.verdict == "FAIL"
    assert R.numberOfFails == 3

def test_nonbool_precond():
    checker1 = copy.copy(checker0)
    checker1.precond = lambda x,y : None
    R = checker1.checkPrecond()
    assert R.verdict == "ABORT"
    assert R.numberOfFails == 0

def test_nonbool_postcond1():
    checker1 = copy.copy(checker0)
    checker1.postcond = lambda retval,x,y: None
    R = checker1.checkPostcond()
    assert R.verdict == "ABORT"
    assert R.numberOfFails == 0

def test_wrong_postcond1():
    checker1 = copy.copy(checker0)
    checker1.postcond = lambda retval,x,y: retval==x or retval==y
    #(retval==x or retval==y) and (retval <= x and retval <= y)
    R = checker1.checkPostcond()
    assert R.verdict == "FAIL"
    assert R.numberOfFails > 0

def test_wrong_postcond2():
    checker1 = copy.copy(checker0)
    checker1.postcond = lambda retval,x,y: retval <= x and retval <= y
    R = checker1.checkPostcond()
    assert R.verdict == "FAIL"
    assert R.numberOfFails > 0

def test_wrong_postcond3():
    checker1 = copy.copy(checker0)
    checker1.postcond = lambda retval,x,y: (retval==x or retval==y) and (retval < x and retval < y)
    R = checker1.checkPostcond()
    assert R.verdict == "FAIL"
    assert R.numberOfFails > 0

def test_wrong_postcond4():
    checker1 = copy.copy(checker0)
    checker1.postcond = lambda retval,x,y: (retval==x or retval==y) and (retval >= x and retval >= y)
    R = checker1.checkPostcond()
    assert R.verdict == "FAIL"
    assert R.numberOfFails > 0