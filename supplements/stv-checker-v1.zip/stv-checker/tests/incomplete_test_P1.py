import copy
from exercises_invs import P1

def test_simulator() :
    # run the simulator to simulate P1, passing i=2, j=20
    P1.checker.simulateLoop(2,20) 

