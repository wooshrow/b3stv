import copy
from exercises_invs import MUL

def test_simulator() :
    # run the simulator to simulate MUL, passing X=3, Y=8
    MUL.checker.simulateLoop(3,8)
