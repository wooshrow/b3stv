from exercises_specs import MIN

def test_pre():
   R = MIN.checker.checkPrecond()
   assert R.verdict == "PASS"

def test_post():
   R = MIN.checker.checkPostcond()
   assert R.verdict == "PASS"