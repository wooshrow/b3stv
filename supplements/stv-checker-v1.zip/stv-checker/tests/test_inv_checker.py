from formalspecs.checker import Checker
import numpy as np
import numpy.typing as npt
import copy

def foo(x:int, a:npt.NDArray[int]) -> bool :
    i = 0
    r = False
    while i < len(a):
        r = r or (a[i]==x)
        i += 1
    return r

checker = Checker(foo, 
                  lambda x,a: a is not None, # precond
                  lambda r,i,x,a: r == any([x == a[i] for i in range(0,len(a))]) # post-cond
                  )
def stmtBefore(x,a):
    i = 0 ;
    r = False ;
    return (r,i,x,a)

def loopBody(r,i,x,a) :
    if i<0 or i>len(a):
        raise IndexError(f"trying to access an array outside its valid indices: {i}")
    r = r or (a[i]==x)
    i += 1
    return (r,i,x,a)

checker.varnames = ["r","i","x","a"]
checker.stmtBefore = stmtBefore
checker.loopGuard = lambda r,i,x,a: i < len(a)
checker.loopBody = loopBody
#checker.stmtAfter = lambda r,i,x,a: (r,i,x,a)
checker.inv = lambda r,i,x,a : (
    0 <= i 
    and i <= len(a)
    and r == any([a[k]==x for k in range(0,i)])
    )
checker.m = lambda r,i,x,a: len(a) - i

checker.precondTests = [ 
        (True,(1,np.array([]))), 
        (True,(1,np.array([0,1]))), (True,(1,np.array([0,1,0]))),
        (True,(2,np.array([0,1]))),
        (False,(1,None))
    ]
checker.PinvTests = [
        (r,i,x,a) for r in [True,False]
        for i in [-1,0,1,2,3,4]
        for x in [9,0]
        for a in [np.array([]),np.array([0]), np.array([1,0]), 
                  np.array([1,0,0]), np.array([1,2,3])]
    ]

def test_simulator() :
    checker.simulateLoop(0,np.array([1,1,0,2]))

def test_checkPinit():
    R = checker.checkPinit()
    assert R.isPASS()

def test_checkPinv():
    R = checker.checkPinv()
    assert R.isPASS()

def test_checkPexit():
    R = checker.checkPexit()
    assert R.isPASS()

def test_checkPTC1():
    R = checker.checkPTC1()
    assert R.isPASS()

def test_checkPTC2():
    R = checker.checkPTC2()
    assert R.isPASS()

def test_wrongm1() :
    checker2 = copy.copy(checker)
    checker2.m = lambda r,i,x,a : i
    checker2.stopAtFirstViolation = True
    R = checker2.checkPTC1()
    assert R.isFAIL()

def test_wrongm2() :
    checker2 = copy.copy(checker)
    checker2.m = lambda r,i,x,a : len(a) - i - 1
    checker2.stopAtFirstViolation = True
    R = checker2.checkPTC2()
    assert R.isFAIL()

def test_inv_too_strong_forInit() :
    checker2 = copy.copy(checker)
    checker2.inv = lambda r,i,x,a : (
        r == any([a[k]==x for k in range(0,len(a))])
    )
    checker2.stopAtFirstViolation = True
    R = checker2.checkPinit()
    assert R.isFAIL()

def test_inv_too_weak_forPost() :
    checker2 = copy.copy(checker)
    checker2.inv = lambda r,i,x,a : 0 <= i and i <= len(a)
    checker2.stopAtFirstViolation = True
    R = checker2.checkPexit()
    assert R.isFAIL()

def test_wrong_inv_forPost() :
    checker2 = copy.copy(checker)
    checker2.inv = lambda r,i,x,a : (
        0 <= i
        and i <= len(a)
        and any([a[k]==x for k in range(0,i)])
    )
    checker2.stopAtFirstViolation = True
    R = checker2.checkPexit()
    assert R.isFAIL()

def test_wrong_inv_forPinv() :
    checker2 = copy.copy(checker)
    checker2.inv = lambda r,i,x,a : 0 <= i and i < len(a)
    checker2.stopAtFirstViolation = True
    R = checker2.checkPinv()
    assert R.isFAIL()

def test_wrong_inv2_forPinv() :
    checker2 = copy.copy(checker)
    checker2.inv = lambda r,i,x,a : (
        i <= len(a)
        and r == any([a[k]==x for k in range(0,i)])
    )
    checker2.stopAtFirstViolation = True
    R = checker2.checkPinv()
    assert R.isFAIL()
    
