import copy
from exercises_invs import PT1

def test_simulator() :
    # run the simulator to simulate PT1, passing k=1
    PT1.checker.simulateLoop(1)
