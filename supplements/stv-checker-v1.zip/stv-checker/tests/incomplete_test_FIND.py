import copy
from exercises_invs import FIND
import numpy as np
#import numpy.typing as npt

def test_simulator() :
    # run the simulator to simulate FIND, passing x=0, N=3,
    # and [1,1,0,2] as the array a
    FIND.checker.simulateLoop(0,3,np.array([1,1,0,2]))
